package controller;

import dto.AskRequest;
import dto.Choice;
import dto.Usage;
import lombok.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import service.ChatbotService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Slf4j
@Controller
@RequestMapping("/chatbot/chatbot_main")
public class ChatbotController {
	
	private final ChatbotService chatbotService;
	
	@Autowired
	public ChatbotController(final ChatbotService chatbotService) {
		this.chatbotService = chatbotService;
	}
	
	@GetMapping
	public String getPage() {
		return "/chatbot/chatbot_main";
	}
	
	
	@PostMapping("/ask")
	@ResponseBody
	public ChatGptResponse chatbotAsk(@RequestBody AskRequest requestDto) {
		return chatbotService.requestOpenAIRequest(requestDto);
	}

	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class MessageDto {
		
		private Messages[] messages;
		
		@Data
		@NoArgsConstructor
		@AllArgsConstructor
		public static class Messages {
			
			private String role;
			
			private String content;
			
		}
		
	}
	
	@Data
	@NoArgsConstructor
	@AllArgsConstructor
	public static class ResponseMessageDto {
		
		private ChatGptResponse response;
		
	}
	@Getter
	@NoArgsConstructor
	public static class ChatGptResponse implements Serializable {

		private String id;
		private String object;
		private LocalDate created;
		private String model;
		private List<Choice> choices;
		private Usage usage;
		@Builder
		public ChatGptResponse(String id, String object,
							   LocalDate created, String model,
							   List<Choice> choices, Usage usage) {
			this.id = id;
			this.object = object;
			this.created = created;
			this.model = model;
			this.choices = choices;
			this.usage = usage;
		}
	}
}
