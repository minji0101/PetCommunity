package controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import dto.PetInfo;
import service.PetService;


//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@Controller
//@RequestMapping("/search")
//public class PetController {
//
//   @GetMapping("/api")
//    public String PetAddMain() {
//        return "search/api";
//    }
//}



@Controller
@RequestMapping("/search")
public class PetController {

    @Autowired
    private PetService petService;

    @GetMapping("/api")
    public String getPetInfo(Model model) {
        try {
            List<PetInfo> petInfoList = petService.getPetInfo();
            model.addAttribute("petInfoList", petInfoList);
            System.out.println("Pet Info List added to model: " + petInfoList); // 추가된 부분
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "search/api";
    }
}