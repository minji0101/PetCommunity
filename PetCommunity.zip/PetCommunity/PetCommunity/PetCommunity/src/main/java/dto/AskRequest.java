package dto;

import lombok.Getter;

import java.io.Serializable;

@Getter
public class AskRequest implements Serializable {
    private String question;
}
