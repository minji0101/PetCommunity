package dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Getter
@NoArgsConstructor
public class ChatGptRequest implements Serializable {

    private String model;
//    private String prompt;
    @JsonProperty("max_tokens")
    private Integer maxTokens;
    private Double temperature;
    private List<ChatGptMessage> messages;
//    @JsonProperty("top_p")
//    private Double topP;

    @Builder
    public ChatGptRequest(String model, /* String prompt, */
                          Double temperature
                          ,List<ChatGptMessage> messages /*, Double topP */) {
        this.model = model;
        //this.prompt = prompt;
        this.temperature = temperature;
        this.messages = messages;
//        this.topP = topP;
    }
}