package dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import controller.ChatbotController;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Getter
@NoArgsConstructor
public class Choice implements Serializable {


    private Integer index;
    @JsonProperty("finish_reason")
    private String finishReason;
    private MessageResultDto message;
    @Builder
    public Choice(Integer index, String finishReason, MessageResultDto messageDto) {
        this.message = messageDto;
        this.index = index;
        this.finishReason = finishReason;
    }
}