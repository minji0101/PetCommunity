package dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PetInfo {
    private String sj;
    private String wrter;
    private String writngDe;
    private String cn;
    private String ty3Date;
    private String ty3Place;
    private String ty3Kind;
    private String ty3Sex;
    private String ty3Process;
    private String ty3Ingye;
    private String ty3Insu;
    private String ty3Picture;

    // getters and setters
    public String getSj() {
        return sj;
    }
    public void setSj(String sj) {
        this.sj = sj;
    }
    public String getWrter() {
        return wrter;
    }
    public void setWrter(String wrter) {
        this.wrter = wrter;
    }
    public String getWritngDe() {
        return writngDe;
    }
    public void setWritngDe(String writngDe) {
        this.writngDe = writngDe;
    }
    public String getCn() {
        return cn;
    }
    public void setCn(String cn) {
        this.cn = cn;
    }
    public String getTy3Date() {
        return ty3Date;
    }
    public void setTy3Date(String ty3Date) {
        this.ty3Date = ty3Date;
    }
    public String getTy3Place() {
        return ty3Place;
    }
    public void setTy3Place(String ty3Place) {
        this.ty3Place = ty3Place;
    }
    public String getTy3Kind() {
        return ty3Kind;
    }
    public void setTy3Kind(String ty3Kind) {
        this.ty3Kind = ty3Kind;
    }
    public String getTy3Sex() {
        return ty3Sex;
    }
    public void setTy3Sex(String ty3Sex) {
        this.ty3Sex = ty3Sex;
    }
    public String getTy3Process() {
        return ty3Process;
    }
    public void setTy3Process(String ty3Process) {
        this.ty3Process = ty3Process;
    }
    public String getTy3Ingye() {
        return ty3Ingye;
    }
    public void setTy3Ingye(String ty3Ingye) {
        this.ty3Ingye = ty3Ingye;
    }
    public String getTy3Insu() {
        return ty3Insu;
    }
    public void setTy3Insu(String ty3Insu) {
        this.ty3Insu = ty3Insu;
    }
    public String getTy3Picture() {
        return ty3Picture;
    }
    public void setTy3Picture(String ty3Picture) {
        this.ty3Picture = ty3Picture;
    }
}