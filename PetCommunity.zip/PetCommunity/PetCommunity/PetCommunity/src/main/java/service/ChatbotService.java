package service;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import config.ChatGptConfig;
import controller.ChatbotController;
import controller.ChatbotController.MessageDto;
import dto.AskRequest;
import dto.ChatGptMessage;
import dto.ChatGptRequest;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class ChatbotService {
	private static RestTemplate restTemplate = new RestTemplate();
	private final ObjectMapper objectMapper = new ObjectMapper();
	
	public static final MessageDto.Messages SYSTEM_PROMPT = new MessageDto.Messages(
			"system",
			"You are a helpful assistant for movie recommendation. Reply response as korean, but only about movie topics. Otherwise, deny replying to user's request."
	);
	
	@Autowired
	public ChatbotService() {
		objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
	}

	private HttpEntity<ChatGptRequest> buildHttpEntity(ChatGptRequest requestDto) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType(ChatGptConfig.MEDIA_TYPE));
		headers.add(ChatGptConfig.AUTHORIZATION, ChatGptConfig.BEARER + ChatGptConfig.API_KEY);
		System.setProperty("https.protocols", "TLSv1.2"); //TLS 버전을 맞추기 위함
		return new HttpEntity<>(requestDto, headers);
	}

	private ChatbotController.ChatGptResponse getResponse(HttpEntity<ChatGptRequest> chatGptRequestDtoHttpEntity) {
		ResponseEntity<ChatbotController.ChatGptResponse> responseEntity = restTemplate.postForEntity(
				ChatGptConfig.URL,
				chatGptRequestDtoHttpEntity,
				ChatbotController.ChatGptResponse.class);

		return responseEntity.getBody();
	}
	public ChatbotController.ChatGptResponse requestOpenAIRequest(AskRequest requestDto) {
		List<ChatGptMessage> messages = new ArrayList<>();
		messages.add(ChatGptMessage.builder()
				.role(ChatGptConfig.ROLE)
				.content(requestDto.getQuestion())
				.build());

		return this.getResponse(
				this.buildHttpEntity(
						new ChatGptRequest(
								ChatGptConfig.MODEL,
								//requestDto.getQuestion(),
								ChatGptConfig.TEMPERATURE,
								messages
								//, ChatGptConfig.TOP_P
						)
				)
		);
	}
}