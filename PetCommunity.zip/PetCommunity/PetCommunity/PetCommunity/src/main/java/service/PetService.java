package service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import dto.PetInfo;

import org.springframework.stereotype.Service;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

@Service
public class PetService {
    public List<PetInfo> getPetInfo() throws IOException {
        String serviceKey = "qDkVcvPA4JfMjMxmAMF0VBfN45acSjJ9jazKEosY8j0Y4cRz%2B3INVNuToJuKO2Ck1RXKWkkpd%2BvMbsrlyHvHdQ%3D%3D";
        StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/6260000/BusanPetAnimalInfoService/getPetAnimalInfo");
        urlBuilder.append("?" + URLEncoder.encode("serviceKey", "UTF-8") + "=" + serviceKey);
        urlBuilder.append("&" + URLEncoder.encode("pageNo", "UTF-8") + "=" + URLEncoder.encode("1", "UTF-8"));
        urlBuilder.append("&" + URLEncoder.encode("numOfRows", "UTF-8") + "=" + URLEncoder.encode("10", "UTF-8"));
        urlBuilder.append("&" + URLEncoder.encode("resultType", "UTF-8") + "=" + URLEncoder.encode("json", "UTF-8"));

        URL url = new URL(urlBuilder.toString());
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Content-type", "application/json");
        BufferedReader rd;
        if (conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } else {
            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
        }
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);
        }
        rd.close();
        conn.disconnect();

        System.out.println("API Response: " + sb.toString());

        // JSON 파싱
        ObjectMapper objectMapper = new ObjectMapper();
        JsonNode rootNode = objectMapper.readTree(sb.toString());
        JsonNode itemsNode = rootNode.path("getPetAnimalInfo").path("body").path("items").path("item");

        List<PetInfo> petInfoList = new ArrayList<>();
        if (itemsNode.isArray()) {
            for (JsonNode itemNode : itemsNode) {
                PetInfo petInfo = new PetInfo();
                petInfo.setSj(itemNode.path("sj").asText());
                petInfo.setWrter(itemNode.path("wrter").asText());
                petInfo.setWritngDe(itemNode.path("writngDe").asText());
                petInfo.setCn(itemNode.path("cn").asText());
                petInfo.setTy3Date(itemNode.path("ty3Date").asText());
                petInfo.setTy3Place(itemNode.path("ty3Place").asText());
                petInfo.setTy3Kind(itemNode.path("ty3Kind").asText());
                petInfo.setTy3Sex(itemNode.path("ty3Sex").asText());
                petInfo.setTy3Process(itemNode.path("ty3Process").asText());
                petInfo.setTy3Ingye(itemNode.path("ty3Ingye").asText());
                petInfo.setTy3Insu(itemNode.path("ty3Insu").asText());
                petInfo.setTy3Picture(itemNode.path("ty3Picture").asText());
                petInfoList.add(petInfo);
            }
        }
        System.out.println("Parsed Pet Info List: " + petInfoList);
        return petInfoList;
    }
}