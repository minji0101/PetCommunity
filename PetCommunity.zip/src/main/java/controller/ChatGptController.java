package controller;

import dto.ChatGptResponse;
import dto.QuestionRequest;
import service.ChatGptService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/chatbot")
public class ChatGptController {

	private final ChatGptService chatGptService;

	public ChatGptController(ChatGptService chatGptService) {

		this.chatGptService = chatGptService;
	}

	@PostMapping("/question")
	public ChatGptResponse sendQuestion(@RequestBody QuestionRequest requestDto) {
		return chatGptService.askQuestion(requestDto);
	}
	
	
}